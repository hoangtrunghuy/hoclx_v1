code for learn drive
