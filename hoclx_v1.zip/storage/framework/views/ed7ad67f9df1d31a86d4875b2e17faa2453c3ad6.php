
<p> Xác nhận cho tài khoản <?php echo e($name); ?>

    <br>
    Nhấn vào
    <button href="localhost:8000/verify/<?php echo e($id); ?>/<?php echo e($token); ?>">để xác nhận</button> </p>
<script>
    alert(12);
</script>