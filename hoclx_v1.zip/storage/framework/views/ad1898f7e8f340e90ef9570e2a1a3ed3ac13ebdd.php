<?php $__env->startSection('content'); ?>

	<section style="margin: 20px 0px;">
		<div class="container">
			<div class="row">
				<div class="col-md-8 mx-auto">
					<h2 class="text-center">Bộ 450 câu hỏi sát hạch lái xe Ôtô:</h2><br><br>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-12 form-group form-control" >
						<p style="color:red;"><b>Câu số <?php echo e(++$key); ?>:</b></p>
						<h4><?php echo e($value->question_content); ?></h4>
						<img src="<?php echo e($value->question_img); ?>" alt="" width="100%">
						<ul>
							<li>
								<label >
								    * <?php echo e($value->question_ansA); ?> 

								    <?php if(strpos($value->question_answerTrue, 'a') !== false): ?> 
								    	<i class="fa fa-2x fa-check-circle text-success"></i>
								    <?php endif; ?>
								</label>
							</li>
							<li>
								<label>
								    * <?php echo e($value->question_ansB); ?>


								    <?php if(strpos($value->question_answerTrue, 'b') !== false): ?> 
								    	<i class="fa fa-2x fa-check-circle text-success"></i>
								    <?php endif; ?>
								</label>
							</li>
							<li>
								<label>
								    * <?php echo e($value->question_ansC); ?>


								    <?php if(strpos($value->question_answerTrue, 'c') !== false): ?> 
								    	<i class="fa fa-2x fa-check-circle text-success"></i>
								    <?php endif; ?>
								</label>
							</li>
							<li>
								<label>
								    * <?php echo e($value->question_ansD); ?>


								    <?php if(strpos($value->question_answerTrue, 'd') !== false): ?> 
								    	<i class="fa fa-2x fa-check-circle text-success"></i>
								    <?php endif; ?>
								</label>
							</li>
						</ul>	
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
			</div>
		</div>

	</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>