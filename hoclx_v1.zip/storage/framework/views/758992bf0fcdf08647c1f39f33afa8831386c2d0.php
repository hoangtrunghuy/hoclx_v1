<!-- Bootstrap Core CSS -->
<link href="<?php echo e('admin/vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="<?php echo e('admin/vendor/metisMenu/metisMenu.min.css'); ?>" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo e('admin/dist/css/sb-admin-2.css'); ?>" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="<?php echo e('admin/vendor/morrisjs/morris.css'); ?>" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo e('admin/vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="<?php echo e(asset('css/sb-admin-2.css')); ?>" rel="stylesheet">