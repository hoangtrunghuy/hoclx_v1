<!DOCTYPE html>
<html lang="en">

<head>

    <title>Học Lái Xe Ôtô</title>
    <meta charset="UTF-8">
    <meta name="description" content="AuCreative theme tempalte">
    <meta name="author" content="AuCreative">
    <meta name="keywords" content="AuCreative theme template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <base href="<?php echo e(asset('')); ?>">

<?php echo $__env->make('client.effect.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body class="animsition restyle-index">


<header>
    <!-- Header desktop -->
    <div class="container-menu-desktop">
        <?php echo $__env->make('client.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('client.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</header>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('client.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('client.effect.javascript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>