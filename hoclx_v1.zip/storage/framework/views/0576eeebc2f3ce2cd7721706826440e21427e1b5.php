<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('client.slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('client.loaidethi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('client.feedback', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('client.tip', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('client.callback', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('client.thongtinlaixe', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>