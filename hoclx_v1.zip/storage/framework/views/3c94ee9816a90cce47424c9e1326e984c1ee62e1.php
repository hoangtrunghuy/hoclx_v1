    <?php $__env->startSection('content'); ?>
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Thêm câu hỏi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Nhập thông tin câu hỏi mới
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-2"></div>
                                <div class="col-lg-8">
                                    <form action="<?php echo e(route('questions.update',$model->id)); ?>" method="post" role="form"> 
                                    <?php echo e(@csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                        <div class="form-group">
                                            <label>Chọn loại câu hỏi</label>
                                            <select class="form-control" name="question_type">
                                                <option value="1">Lý thuyết</option>
                                                <!-- <option>Nghiệp vụ vận tải</option>
                                                <option>Văn hóa lái xe</option>
                                                <option>Kỹ thuật sửa chữa</option> -->
                                                <option value="2">Biển báo</option>
                                                <option value="3">Sa Hình</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nhập nội dung câu hỏi</label>
                                            <textarea class="form-control" rows="3" name="question_content" required><?php echo e($model->question_content); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                        	<img src="<?php echo e($model->question_img); ?>" alt=""/>
                                            <label>Chèn ảnh</label>
                                            <input type="file">
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="optionsRadios" id="optionsRadios1" value="option1" checked>Chọn Là Đúng
                                            </label>
                                            <input class="form-control" placeholder="Nhập đáp án A" value="<?php echo e($model->question_ansA); ?>" name="question_ansA" required>
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="optionsRadios" id="optionsRadios1" value="option1" >Chọn Là Đúng
                                            </label>
                                            <input class="form-control" placeholder="Nhập đáp án B" value="<?php echo e($model->question_ansB); ?>" name="question_ansB" required>
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="optionsRadios" id="optionsRadios1" value="option1" >Chọn Là Đúng
                                            </label>
                                            <input class="form-control" placeholder="Nhập đáp án C" value="<?php echo e($model->question_ansC); ?>" name="question_ansC">
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="optionsRadios" id="optionsRadios1" value="option1" >Chọn Là Đúng
                                            </label>
                                            <input class="form-control" placeholder="Nhập đáp án D" value="<?php echo e($model->question_ansD); ?>" name="question_ansD">
                                            <input class="form-control" placeholder="Nhập key đáp án" name="question_answerTrue">
                                        </div>
                                        <button type="submit" class="btn btn-default" name="">Lưu</button>
                                        <button type="reset" class="btn btn-default">Hủy bỏ</button>
                                    </form>
                                </div>
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>