<section class="testimonial" id="feed">
    <div class="wrap-testimonial parallax100 bg-overlay-3 p-t-75 p-b-80"
         >
        <div class="wrap-slide-slick-1">
            <div class="p-b-40">
                <h3 class="m-txt6 txt-center p-b-8 respon1">
                    SỰ HÀI LÒNG CỦA HỌC VIÊN CHÍNH LÀ THÀNH CÔNG LỚN NHẤT CỦA CHÚNG TÔI.
                </h3>

                <div class="bg-main size2 bo-rad-3 m-lr-auto"></div>
            </div>

            <div class="slide-slick-1 js-slick-1">
                <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide-slick-1 js-slick-1">
                        <div class="item-slick-1">
                            <p class="para-slide-slick-1 m-lr-auto w-size1 s-txt1 txt-center p-l-40 p-r-40 p-b-25 animated">
                                <?php echo e($item->feedback_content); ?>

                            </p>

                            <div class="wrap-person m-lr-auto flex-c-m animated">
                                <div class="wrap-pic-person">
                                    <img src="<?php echo e($item->user->user_img); ?>" alt="IMG-PERSON">
                                </div>

                                <div class="wrap-info-person p-l-20">
                                    <span class="dis-block s-txt3"><?php echo e($item->user->user_firstName . ' ' . $item->user->user_lastName); ?></span>
                                    <span class="dis-block s-txt4"><?php echo e($item->user->user_adress); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</section>
