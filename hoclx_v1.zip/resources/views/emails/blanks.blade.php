<table border="1">
	<tr>
		<td align="center">Họ tên</td>
		<td align="center">Email</td>
		<td>Số điện thoại</td>
		<td align="center">Nội dung</td>
	</tr>
	<tr>
		<td>{{ $name }}</td>
		<td>{{ $email }}</td>
		<td>{{ $phone }}</td>
		<td>{{ $contact_content }}</td>
	</tr>
</table>