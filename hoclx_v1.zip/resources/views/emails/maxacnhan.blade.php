
<p> Xác nhận cho tài khoản {{$name}}
    <br>
    Nhấn vào
    <button href="localhost:8000/verify/{{$id}}/{{$token}}">để xác nhận</button> </p>
<script>
    alert(12);
</script>