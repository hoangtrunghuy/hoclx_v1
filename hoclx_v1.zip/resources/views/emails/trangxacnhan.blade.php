<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Xác nhận</title>
</head>
<body>
	<div>
		<div>
			<p><b>Nhập mã xác nhận</b></p>
			<hr>
		</div>
		<div>
			<p>Vui lòng kiểm tra tin nhắn có chứa mã trong thư của bạn. Mã của bạn gồm 6 số.
		</div>
		<form method="POST" action="#">
			<input type="text" name="maxacnhan">
			<input type="submit" value="Gởi">
		</form>
	</div>
</body>
</html>