<div class="top-bar bg-main">
    <div class="container">
        <div class="content-topbar">
            <div class="left-top-bar">
                </form action="" method="">
                <input type="text" name="">
                <input type="submit" name="" value="Tìm Kiếm">
                </form>
            </div>

            <div class="right-top-bar">
							<span>
								<i class="icon_phone" aria-hidden="true"></i>
								<span>0968 437 320</span>
							</span>

                <span>
								<i class="icon_pin" aria-hidden="true"></i>
								<span>Trường Đại học Công Nghiệp Hà Nội</span>
							</span>

                <span>
								<i class="icon_clock" aria-hidden="true"></i>
								<span>09:30 am – 06:00 pm</span>
							</span>
            </div>
        </div>
    </div>
</div>
