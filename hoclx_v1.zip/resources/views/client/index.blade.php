@extends('layouts.client')
@section('content')

    @include('client.slide')
    @include('client.loaidethi')
    @include('client.feedback')
    @include('client.tip')
    @include('client.callback')
    @include('client.thongtinlaixe')
@endsection